<?php
class OverallsController extends AppController {

	var $name = 'Overalls';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category','Color','Album','Overating'); 
	function index($id=null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$data['Overall'] = $this->data['Overall'];
			//$data['Overall']
			
				

	$ftong="../../app/webroot/css/stylemain.css"; //Khai báo đường dẫn của file cần ghi dữ liệu

			
			// Khởi tạo css cho toàn bộn trang------------------------------------------------------------------------>
   @$fttong=fopen($ftong,"w"); //Mở file cần ghi
//body--------------------------
   $body1='body {
	margin:0px;
	font-family:Arial, Helvetica, sans-serif;
	font-size: '.$_POST['w2'].'px;
	background:url(../'.$_SESSION['maubg'].') scroll;
	color:'.$_SESSION['mauchu'].';
}
*{
    padding: 0;
    margin: 0;
}
img{
    border: 0;
}
a{
	text-decoration:none;
}
li{
    list-style: none;
}
';
// main------------------------>
$wrapper='
#q_warrper{
	width:'.$_POST['w1'].'px;
	height:auto;
	margin:auto;
	overflow:hidden;
	background:'.$_SESSION['maunen'].';
	}';
if($_POST['gocbo']==0){
				$title='
#q_title{
	background:url(../'.$_SESSION['maubgtd'].') repeat-x;
	color:'.$_SESSION['mauchtd'].';
	height:'.$_POST['htd'].'px;
	float:left;
	overflow:hidden;
	width:100%;
	border-top-left-radius:'.$_POST['btd'].'px;
	border-top-right-radius:'.$_POST['btd'].'px;
	}
';
				
			}
			if($_POST['gocbo']==1)
	{
				$title='
#q_title{
	background:url(../'.$_SESSION['maubgtd'].') repeat-x;
	color:'.$_SESSION['mauchtd'].';
	height:'.$_POST['htd'].'px;
	float:left;
	overflow:hidden;
	width:100%;
    border-radius:'.$_POST['btd'].'px;
	}
 #q_title p{
	 float:left;
		margin-left:5px;
		font-weight:bold;
		line-height:'.$_POST['htd'].'px;
		text-transform:uppercase;
	} 
';
				
		}
			

//pr($title);die;
//baner------------------------------------------->
//pr($cat['Overall']['mainother']);die;

   $ftong=$body1.$wrapper.$title; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong,$ftong); //thực hiện việc sinh file css của toan trang------------------------------------------------------>
  // $f1="css/demo.php";
  // @ $ft1=fopen($f1,"w");
   // $f1='<?php echo "aaaaaaaaaaa";';
    //fwrite($ft1,$f1); //Thực hiện ghi nội dung vào file
	$data['Overall']['mainchose']=$_POST['baner1'].'/'.$_POST['menu1'].'/'.$_POST['slide1'].'/'.$_POST['left1'].'/'.$_POST['right1'].'/'.$_POST['slideend'];
	$data['Overall']['maincss']=$body1.$wrapper.$title;
	$data['Overall']['mainsize']=$_SESSION['maubg'].'</>'.$_POST['w1'].'</>'.$_POST['w2'].'</>'.$_SESSION['mauchu'].'</>'.$_SESSION['maunen'].'</>'.$_SESSION['mauchtd'].'</>'.$_SESSION['maubgtd'].'</>'.$_POST['htd'].'</>'.$_POST['btd'].'</>'.$_POST['gocbo'];
	//pr($data['Overall']['mainsize']);die;
	
	if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."overalls'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
		$this->set('chosemain',explode('</>',$catmain['Overall']['mainsize']));
		//pr(explode('</>',$catmain['Overall']['mainsize']));die;
	$c= $this->Color->find('all',array('conditions'=>array(),'order'=>'Color.id ASC'));
	$choscolor=explode('</>',$catmain['Overall']['mainsize']);
	$_SESSION['mauchu']= $choscolor[3];
	$_SESSION['maubg']=$choscolor[0];
	$_SESSION['maunen']=$choscolor[4];
	$_SESSION['mauchtd']=$choscolor[5];
	$_SESSION['maubgtd']=$choscolor[6];
	
		$this->set('color', $c);	 
	}
	
	
	
	function setcolor(){
		$id=$_GET['id'];
		$this->layout='ajax';
		$mauchu=$this->set('color',$this->Color->read(null,$id));
		$mauchu=$this->Color->read(null,$id);
		$_SESSION['mauchu']=$mauchu['Color']['color'];
	}
	function setcolor1(){
		$id=$_GET['id'];
		$this->layout='ajax';
		$mauchu=$this->set('color',$this->Color->read(null,$id));
		$mauchu=$this->Color->read(null,$id);
		$_SESSION['maunen']=$mauchu['Color']['color'];
	}
	function setcolortd(){
		$id=$_GET['id'];
		$this->layout='ajax';
		$mauchu=$this->set('color',$this->Color->read(null,$id));
		$mauchu=$this->Color->read(null,$id);
		$_SESSION['mauchtd']=$mauchu['Color']['color'];
	}
	function setbg(){
		$id=$_GET['id'];
		$this->layout='ajax';
		$mauchu=$this->set('album',$this->Album->read(null,$id));
		$mauchu=$this->Album->read(null,$id);
		$_SESSION['maubg']=$mauchu['Album']['images'];
	}
	function setbgtd(){
		$id=$_GET['id'];
		$this->layout='ajax';
		$mauchu=$this->set('album',$this->Album->read(null,$id));
		$mauchu=$this->Album->read(null,$id);
		$_SESSION['maubgtd']=$mauchu['Album']['images'];
	}
	function save(){
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
		$this->set('chosemain',explode('</>',$catmain['Overall']['mainsize']));
		//pr(explode('</>',$catmain['Overall']['mainsize']));die;
	$c= $this->Color->find('all',array('conditions'=>array(),'order'=>'Color.id ASC'));
	$choscolor=explode('</>',$catmain['Overall']['mainsize']);
	$_SESSION['mauchu']= $choscolor[3];
	$_SESSION['maubg']=$choscolor[0];
	$_SESSION['maunen']=$choscolor[4];
	$_SESSION['mauchtd']=$choscolor[5];
	$_SESSION['maubgtd']=$choscolor[6];
		}
		function add(){
			 $x=array();
			 	$catmain=$this->Overall->read(null,1);
				//pr($catmain);die;
			 $x['Overating']['type']=$_POST['wbaner'];
			 $x['Overating']['images']=$_POST['loai'];
			 $x['Overating']['name']=$_POST['name'];
 			 $x['Overating']['slidecss']=$catmain['Overall']['slidecss'];
			 $x['Overating']['slidehtml']=$catmain['Overall']['slidehtml'];
			 $x['Overating']['slidechose']=$catmain['Overall']['slidechose'];
			 $x['Overating']['contentcss']=$catmain['Overall']['contentcss'];
			 $x['Overating']['sizetong']=$catmain['Overall']['sizetong'];
			 $x['Overating']['chosetong']=$catmain['Overall']['chosetong'];
			 $x['Overating']['rightmodulsize']=$catmain['Overall']['rightmodulsize'];
			 $x['Overating']['rightmodul']=$catmain['Overall']['rightmodul'];
			 $x['Overating']['rightcss']=$catmain['Overall']['rightcss'];
			 $x['Overating']['righthtml']=$catmain['Overall']['righthtml'];
			 $x['Overating']['rightvt']=$catmain['Overall']['rightvt'];
			 $x['Overating']['rightchose']=$catmain['Overall']['rightchose'];
			 $x['Overating']['leftmodulsize']=$catmain['Overall']['leftmodulsize'];
			 $x['Overating']['leftmodul']=$catmain['Overall']['leftmodul'];
			 $x['Overating']['leftcss']=$catmain['Overall']['leftcss'];
			 $x['Overating']['lefthtml']=$catmain['Overall']['lefthtml'];
			 $x['Overating']['leftvt']=$catmain['Overall']['leftvt'];
			 $x['Overating']['leftchose']=$catmain['Overall']['leftchose'];
			 $x['Overating']['menuhtml']=$catmain['Overall']['menuhtml'];
			 $x['Overating']['mensize']=$catmain['Overall']['mensize'];
			 $x['Overating']['menutype']=$catmain['Overall']['menutype'];
			 $x['Overating']['codecontentcss']=$catmain['Overall']['codecontentcss'];
			 $x['Overating']['codefooterhtml']=$catmain['Overall']['codefooterhtml'];
			 $x['Overating']['codepatnerhtml']=$catmain['Overall']['codepatnerhtml'];
			 $x['Overating']['coderightcss']=$catmain['Overall']['coderightcss'];
			 $x['Overating']['coderighthtml']=$catmain['Overall']['coderighthtml'];
			 $x['Overating']['codeleftcss']=$catmain['Overall']['codeleftcss'];
			 $x['Overating']['codelefthtml']=$catmain['Overall']['codelefthtml'];
		     $x['Overating']['codeslidecss']=$catmain['Overall']['codeslidecss'];
			 $x['Overating']['codeslidehtml']=$catmain['Overall']['codeslidehtml'];
			 $x['Overating']['codemenucss']=$catmain['Overall']['codemenucss'];
			 $x['Overating']['codebanercss']=$catmain['Overall']['codebanercss'];
			 $x['Overating']['codebanerhtml']=$catmain['Overall']['codebanerhtml'];
			 $x['Overating']['banercss']=$catmain['Overall']['banercss'];
			 $x['Overating']['banerchose']=$catmain['Overall']['banerchose'];
			 $x['Overating']['mainsize']=$catmain['Overall']['mainsize'];
			 $x['Overating']['mainhtml']=$catmain['Overall']['mainhtml'];
			 $x['Overating']['mainother']=$catmain['Overall']['mainother'];
			 $x['Overating']['maincss']=$catmain['Overall']['maincss'];
			 $x['Overating']['mainchose']=$catmain['Overall']['mainchose'];	
			 $x['Overating']['ptchose']=$catmain['Overall']['ptchose'];			 
			 $x['Overating']['ptcss']=$catmain['Overall']['ptcss'];			 
			 $x['Overating']['pthtml']=$catmain['Overall']['pthtml'];			 
			 $x['Overating']['ftchose ']=$catmain['Overall']['ftchose'];	
			 $x['Overating']['ftcss']=$catmain['Overall']['ftcss'];			 
			 $x['Overating']['fthtml']=$catmain['Overall']['fthtml'];			 

			if ($this->Overating->save( $x)) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."overalls'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		 
			
			}
	//Them bai viet
	
	
	function view(){
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
		$this->set('chosemain',explode('</>',$catmain['Overall']['mainsize']));
		//pr(explode('</>',$catmain['Overall']['mainsize']));die;
	$c= $this->Color->find('all',array('conditions'=>array(),'order'=>'Color.id ASC'));
	$choscolor=explode('</>',$catmain['Overall']['mainsize']);
	$_SESSION['mauchu']= $choscolor[3];
	$_SESSION['maubg']=$choscolor[0];
	$_SESSION['maunen']=$choscolor[4];
	$_SESSION['mauchtd']=$choscolor[5];
	$_SESSION['maubgtd']=$choscolor[6];
	$x= $this->Overating->find('all',array('conditions'=>array('Overating.images'=>1 ),'order'=>'Overating.id DESC'));
	$this->set('view',$x);
	$x2= $this->Overating->find('all',array('conditions'=>array('Overating.images'=>2 ),'order'=>'Overating.id DESC'));
	$this->set('view2',$x2);
	$x3= $this->Overating->find('all',array('conditions'=>array('Overating.images'=>3 ),'order'=>'Overating.id DESC'));
	$this->set('view3',$x3);

	}
	function addweb($id=null){
		 $x=array();
			 	$catmain=$this->Overating->read(null,$id);
							 $x['Overall']['slidecss']=$catmain['Overating']['slidecss'];
			 $x['Overall']['slidehtml']=$catmain['Overating']['slidehtml'];
			 $x['Overall']['slidechose']=$catmain['Overating']['slidechose'];
			 $x['Overall']['contentcss']=$catmain['Overating']['contentcss'];
			 $x['Overall']['sizetong']=$catmain['Overating']['sizetong'];
			 $x['Overall']['chosetong']=$catmain['Overating']['chosetong'];
			 $x['Overall']['rightmodulsize']=$catmain['Overating']['rightmodulsize'];
			 $x['Overall']['rightmodul']=$catmain['Overating']['rightmodul'];
			 $x['Overall']['rightcss']=$catmain['Overating']['rightcss'];
			 $x['Overall']['righthtml']=$catmain['Overating']['righthtml'];
			 $x['Overall']['rightvt']=$catmain['Overating']['rightvt'];
			 $x['Overall']['rightchose']=$catmain['Overating']['rightchose'];
			 $x['Overall']['leftmodulsize']=$catmain['Overating']['leftmodulsize'];
			 $x['Overall']['leftmodul']=$catmain['Overating']['leftmodul'];
			 $x['Overall']['leftcss']=$catmain['Overating']['leftcss'];
			 $x['Overall']['lefthtml']=$catmain['Overating']['lefthtml'];
			 $x['Overall']['leftvt']=$catmain['Overating']['leftvt'];
			 $x['Overall']['leftchose']=$catmain['Overating']['leftchose'];
			 $x['Overall']['menuhtml']=$catmain['Overating']['menuhtml'];
			 $x['Overall']['mensize']=$catmain['Overating']['mensize'];
			 $x['Overall']['menutype']=$catmain['Overating']['menutype'];
			 $x['Overall']['codecontentcss']=$catmain['Overating']['codecontentcss'];
			 $x['Overall']['codefooterhtml']=$catmain['Overating']['codefooterhtml'];
			 $x['Overall']['codepatnerhtml']=$catmain['Overating']['codepatnerhtml'];
			 $x['Overall']['coderightcss']=$catmain['Overating']['coderightcss'];
			 $x['Overall']['coderighthtml']=$catmain['Overating']['coderighthtml'];
			 $x['Overall']['codeleftcss']=$catmain['Overating']['codeleftcss'];
			 $x['Overall']['codelefthtml']=$catmain['Overating']['codelefthtml'];
		     $x['Overall']['codeslidecss']=$catmain['Overating']['codeslidecss'];
			 $x['Overall']['codeslidehtml']=$catmain['Overating']['codeslidehtml'];
			 $x['Overall']['codemenucss']=$catmain['Overating']['codemenucss'];
			 $x['Overall']['codebanercss']=$catmain['Overating']['codebanercss'];
			 $x['Overall']['codebanerhtml']=$catmain['Overating']['codebanerhtml'];
			 $x['Overall']['banercss']=$catmain['Overating']['banercss'];
			 $x['Overall']['banerchose']=$catmain['Overating']['banerchose'];
			 $x['Overall']['mainsize']=$catmain['Overating']['mainsize'];
			 $x['Overall']['mainhtml']=$catmain['Overating']['mainhtml'];
			 $x['Overall']['mainother']=$catmain['Overating']['mainother'];
			 $x['Overall']['maincss']=$catmain['Overating']['maincss'];
			 $x['Overall']['mainchose']=$catmain['Overating']['mainchose'];	
			 $x['Overall']['ptchose']=$catmain['Overating']['ptchose'];			 
			 $x['Overall']['ptcss']=$catmain['Overating']['ptcss'];			 
			 $x['Overall']['pthtml']=$catmain['Overating']['pthtml'];			 
			 $x['Overall']['ftchose ']=$catmain['Overating']['ftchose'];	
			 $x['Overall']['ftcss']=$catmain['Overating']['ftcss'];			 
			 $x['Overall']['fthtml']=$catmain['Overating']['fthtml'];
		 	 $x['Overall']['id']=1;
			 $ftong="../../app/webroot/css/stylemain.css"; 			
   			@$fttong=fopen($ftong,"w"); 
			$ftong=$catmain['Overating']['maincss']; // pr( $ftong);die; //Khai báo nội dung của file
    		fwrite($fttong,$ftong);
			
			
			 $ftong1="../../app/webroot/css/stylbaner.css"; 			
   			@$fttong1=fopen($ftong1,"w"); 
			$ftong1=$catmain['Overating']['codebanercss']; // pr( $ftong);die; //Khai báo nội dung của file
    		fwrite($fttong1,$ftong1);
			
			
			 $ftong2="../../app/webroot/css/stylemenu.css"; 			
   			@$fttong2=fopen($ftong2,"w"); 
			$ftong2=$catmain['Overating']['codemenucss']; // pr( $ftong);die; //Khai báo nội dung của file
    		fwrite($fttong2,$ftong2);
			
			 $ftong3="../../app/webroot/css/sliderman.css"; 			
   			@$fttong3=fopen($ftong3,"w"); 
			$ftong3=$catmain['Overating']['codeslidecss']; // pr( $ftong);die; //Khai báo nội dung của file
    		fwrite($fttong3,$ftong3);
			
			 $ftong4="../../app/webroot/css/left.css"; 			
   			@$fttong4=fopen($ftong4,"w"); 
			$ftong4=$catmain['Overating']['codeleftcss']; // pr( $ftong);die; //Khai báo nội dung của file
    		fwrite($fttong4,$ftong4);
			
			$ftong5="../../app/webroot/css/right.css"; 			
   			@$fttong5=fopen($ftong5,"w"); 
			$ftong5=$catmain['Overating']['coderightcss']; // pr( $ftong);die; //Khai báo nội dung của file
    		fwrite($fttong5,$ftong5);
			
			
			$ftong5="../../app/webroot/css/contentstyle.css"; 			
   			@$fttong5=fopen($ftong5,"w"); 
			$ftong5=$catmain['Overating']['codecontentcss']; // pr( $ftong);die; //Khai báo nội dung của file
    		fwrite($fttong5,$ftong5);
			
			$ftong6="../../app/views/layouts/home.ctp"; 			
   			@$fttong6=fopen($ftong6,"w"); 
			$ftong6=$catmain['Overating']['mainhtml'];  //pr( $catmain['Overating']['mainhtml']);die; //Khai báo nội dung của file
    		fwrite($fttong6,$ftong6);
			
			$ftong7="../../app/views/elements/left.ctp"; 			
   			@$fttong7=fopen($ftong7,"w"); 
			$ftong7=$catmain['Overating']['codelefthtml'];  //pr( $catmain['Overating']['mainhtml']);die; //Khai báo nội dung của file
    		fwrite($fttong7,$ftong7);
			
			$ftong8="../../app/views/elements/right.ctp"; 			
   			@$fttong8=fopen($ftong8,"w"); 
			$ftong8=$catmain['Overating']['coderighthtml'];  //pr( $catmain['Overating']['mainhtml']);die; //Khai báo nội dung của file
    		fwrite($fttong8,$ftong8);
			
			$ftong9="../../app/views/elements/baner.ctp"; 			
   			@$fttong9=fopen($ftong9,"w"); 
			$ftong9=$catmain['Overating']['codebanerhtml'];  //pr( $catmain['Overating']['mainhtml']);die; //Khai báo nội dung của file
    		fwrite($fttong9,$ftong9);
			
			$ftong10="../../app/views/elements/slide.ctp"; 			
   			@$fttong10=fopen($ftong10,"w"); 
			$ftong10=$catmain['Overating']['codeslidehtml'];  //pr( $catmain['Overating']['mainhtml']);die; //Khai báo nội dung của file
    		fwrite($fttong10,$ftong10);
			
			$ftong11="../../app/views/elements/paterner.ctp"; 			
   			@$fttong11=fopen($ftong11,"w"); 
			$ftong11=$catmain['Overating']['codepatnerhtml'];  //pr( $catmain['Overating']['mainhtml']);die; //Khai báo nội dung của file
    		fwrite($fttong11,$ftong11);
			
			$ftong12="../../app/views/elements/footers.ctp"; 			
   			@$fttong12=fopen($ftong12,"w"); 
			$ftong12=$catmain['Overating']['codefooterhtml'];  //pr( $catmain['Overating']['mainhtml']);die; //Khai báo nội dung của file
    		fwrite($fttong12,$ftong12);
			
			 if ($this->Overall->save( $x)) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."overalls'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
