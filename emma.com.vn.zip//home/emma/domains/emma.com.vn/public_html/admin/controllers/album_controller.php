<?php
class AlbumController extends AppController {

	var $name = 'Album';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Album','Category','Overall','Color'); 
	function index() {
		//	pr($_POST['wbaner']);die;
		
	}
	function add1() {
		
		if (!empty($this->data)) {
			$this->Album->create();
		$x=explode('/',$_POST['whinh']);
			$data['Album'] = $this->data['Album'];
			$data['Album']['images']='images/'.$x[3];
			$data['Album']['display2']=1;
			if ($this->Album->save($data['Album'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
		$this->set('chosemain',explode('</>',$catmain['Overall']['mainsize']));
		//pr(explode('</>',$catmain['Overall']['mainsize']));die;
	$c= $this->Color->find('all',array('conditions'=>array(),'order'=>'Color.id ASC'));
	$choscolor=explode('</>',$catmain['Overall']['mainsize']);
	$_SESSION['mauchu']= $choscolor[3];
	$_SESSION['maubg']=$choscolor[0];
	$_SESSION['maunen']=$choscolor[4];
	$_SESSION['mauchtd']=$choscolor[5];
	$_SESSION['maubgtd']=$choscolor[6];
	}
		function add2() {
		
		if (!empty($this->data)) {
			$this->Album->create();
		$x=explode('/',$_POST['whinh']);
			$data['Album'] = $this->data['Album'];
			$data['Album']['images']='images/'.$x[3];
			$data['Album']['display2']=2;
			if ($this->Album->save($data['Album'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
	}
		function add3() {
		
		if (!empty($this->data)) {
			$this->Album->create();
		$x=explode('/',$_POST['whinh']);
			$data['Album'] = $this->data['Album'];
			$data['Album']['images']='images/'.$x[3];
			$data['Album']['display2']=3;
			if ($this->Album->save($data['Album'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
	}
		function add4() {
		
		if (!empty($this->data)) {
			$this->Album->create();
		$x=explode('/',$_POST['whinh']);
			$data['Album'] = $this->data['Album'];
			$data['Album']['images']='images/'.$x[3];
			$data['Album']['display2']=4;
			if ($this->Album->save($data['Album'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
	}
	//Them bai viet
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
