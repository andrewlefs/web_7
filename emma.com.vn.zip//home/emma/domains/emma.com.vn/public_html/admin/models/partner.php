<?php
class Partner extends AppModel {
    var $name = 'Partner';
    var $displayField = 'name';
	
}
?>
