<?php
class ProductselaController extends AppController {

	var $name = 'Productsela';
	function index() {
		  $this->account();
		  $_SESSION['menu1']=41;
		  $this->paginate = array('limit' => '15','order' => 'Productsela.id DESC');
	      $this->set('Productsela', $this->paginate('Productsela',array()));
		  

	}
	
	function add(){
		$this->account();
		if($_POST['nam']!=0 and $_POST['thang']!=0){
		$tk=$_POST['nam'].'-'.$_POST['thang'];
		$this->set('name','Tháng '.$_POST['thang'].'năm'.$_POST['nam']);
		}
		if($_POST['nam']==0 and $_POST['thang']!=0){
		$tk='-'.$_POST['thang'].'-';
		$this->set('name','Tháng '.$_POST['thang']);
		}
		if($_POST['nam']!=0 and $_POST['thang']==0){
		$tk=$_POST['nam'].'-';
		$this->set('name','năm'.$_POST['nam']);
		}
		  $this->paginate = array('conditions'=>array('Productsela.created like'=>'%'.$tk.'%'),'limit' => '15','order' => 'Productsela.id DESC');
	      $this->set('Productsela', $this->paginate('Productsela',array()));
		
		//pr($tk);die;
	}
	
	function close($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại ', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Productsela'] = $this->data['Productsela'];
		$data['Productsela']['status']=0;
		if ($this->Productsela->save($data['Productsela'])) {
			$this->Session->setFlash(__('Hình ảnh không được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Hình ảnh không close được', true));
		$this->redirect(array('action' => 'index'));

	}
	
	function active($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại ', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Productsela'] = $this->data['Productsela'];
		$data['Productsela']['status']=1;
		if ($this->Productsela->save($data['Productsela'])) {
			$this->Session->setFlash(__('Hình ảnh được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Hình ảnh không active được', true));
		$this->redirect(array('action' => 'index'));

	}

	function edit($id = null) {
		$this->account();
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại ', true));
			$this->redirect(array('action' => 'index'));
		}
		
		
		$this->set('edit',$this->Productsela->findById($id));
	}
	// Xoa hinh anh
	function delete($id = null) {
		$this->account();		
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại hình ảnh này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Productsela->delete($id)) {
			$this->Session->setFlash(__('Xóa  thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Không xóa được', true));
		$this->redirect(array('action' => 'index'));
	}

	//check ton tai tai khoan
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>
