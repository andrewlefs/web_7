<?php
class Weblink extends AppModel {
    var $name = 'Weblink';
}
?>
