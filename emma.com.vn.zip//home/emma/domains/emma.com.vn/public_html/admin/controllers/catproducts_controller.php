<?php
class CatproductsController extends AppController {

	var $name = 'Catproducts';	
	var $helpers = array('Html', 'Form', 'Javascript', 'TvFck');
	//list danh sach cac danh muc
		var $components = array('function');

	function index() {	
	   $this->account();	 
	  // $conditions=array('Catproduct.status'=>1);	
	   $this->paginate = array('conditions'=>array('Catproduct.parent_id'=>NULL),'limit' => '30','order' => 'Catproduct.id DESC');
	   $this->set('Catproduct', $this->paginate('Catproduct',array()));
       $list_cat = $this->Catproduct->generatetreelist(null,null,null,"--- ");
	   $this->set(compact('list_cat'));
	   $_SESSION['menu1']=1;
	 // pr($_SESSION['menu1']);die;
	}
	function index2($id = null) {	
	   $this->account();	 
	  // $conditions=array('Catproduct.status'=>1);	
	   $this->paginate = array('conditions'=>array('Catproduct.parent_id'=>$id),'limit' => '30','order' => 'Catproduct.id DESC');
	   $this->set('Catproduct', $this->paginate('Catproduct',array()));
	   
	   
        $a=$this->Catproduct->find('all',array('conditions'=>array('Catproduct.id'=>$id),'fields' => array('Catproduct.lft','Catproduct.rght')));
  // pr($a[0]['Category']['lft']);die;
   
  $x=$this->Catproduct->find('list',array('conditions'=>array('Catproduct.status'=>1,'Catproduct.lft >'=>$a[0]['Catproduct']['lft'],'Catproduct.rght <'=>$a[0]['Catproduct']['rght']),'order'=>'Catproduct.id DESC','fields'=>array('Catproduct.id')));//lay vi tri cac danh muc
        $list_cat = $this->Catproduct->generatetreelist(array('Catproduct.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
	  // pr($list_cat);die;
	   $this->set(compact('list_cat'));
	   $_SESSION['menu2']=$id;
	    $_SESSION['menu1']=2;
		$this->set('cat', $this->Catproduct->read(null, $id));
		$cat1=$this->Catproduct->find('list',array('conditions'=>array('Catproduct.id'=>$id),'order'=>'Catproduct.id DESC','fields'=>array('Catproduct.name')));
		$this->set(compact('cat1'));
	 // pr($_SESSION['menu1']);die;
	}
	//tim kiem
	function search() {
		$data['Catproduct']=$this->data['Catproduct'];
	 	$_SESSION['dm']=$_POST['name'];
		//$catproduct=$data['Catproduct']['parent_id'];
		$this->paginate = array('conditions'=>array('Catproduct.name'=>'like %'.$_SESSION['dm'].'%'),'limit' => '15','order' => 'Catproduct.id DESC');
	    $this->set('catproduct', $this->paginate('Catproduct',array()));
		
        $list_cat = $this->Catproduct->generatetreelist(null,null,null,"--- ");
	    $this->set(compact('list_cat'));
		
	}
	//them danh muc moi
	function add() {
		$x=count($this->Catproduct->find('all'));
		$this->set('countdm',$x);
		$this->account();
		if (!empty($this->data)) 
		{
			
			$this->Catproduct->create();
			$data['Catproduct'] = $this->data['Catproduct'];
			$data['Catproduct']['image_thumb'] = $this->function->image_thumb($data['Catproduct']['image']);

			if ($this->Catproduct->save($data['Catproduct'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'add'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
		$this->loadModel("Catproduct");
        $Catproductlist = $this->Catproduct->generatetreelist(null,null,null,"--- ");
        $this->set(compact('Catproductlist'));
	}
	function add2($id=null) {
		$this->account();
		if (!empty($this->data)) 
		{
			if($this->data['Catproduct']['parent_id']=="")
			{
				$this->data['Catproduct']['level']=0;
			}else
			{
				$level=$this->Catproduct->read(null,$this->data['Catproduct']['parent_id']);	
				$this->data['Catproduct']['level']=$level['Catproduct']['level']+1;
			}
			$this->Catproduct->create();
			if ($this->Catproduct->save($this->data)) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'add/'.$id));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
		  $a=$this->Catproduct->find('all',array('conditions'=>array('Catproduct.id'=>$id),'fields' => array('Catproduct.lft','Catproduct.rght')));
  // pr($a[0]['Category']['lft']);die;
   
  $x=$this->Catproduct->find('list',array('conditions'=>array('Catproduct.status'=>1,'Catproduct.lft >'=>$a[0]['Catproduct']['lft'],'Catproduct.rght <'=>$a[0]['Catproduct']['rght']),'order'=>'Catproduct.id DESC','fields'=>array('Catproduct.id')));//lay vi tri cac danh muc
        $list_cat = $this->Catproduct->generatetreelist(array('Catproduct.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
	  // pr($list_cat);die;
	   $this->set(compact('list_cat'));
	 
		$this->set('cat', $this->Catproduct->read(null, $id));
			$cat1=$this->Catproduct->find('list',array('conditions'=>array('Catproduct.id'=>$id),'order'=>'Catproduct.id DESC','fields'=>array('Catproduct.name')));
		$this->set(compact('cat1'));
	 // pr($_SESSION['menu1']);die;
	}
	//Sua danh muc
	function edit($id = null) {
		$this->account();
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
						$data['Catproduct'] = $this->data['Catproduct'];

			$data['Catproduct']['image_thumb'] = $this->function->image_thumb($data['Catproduct']['image']);
			//pr($data['Catproduct']);die;
			if ($this->Catproduct->save($data['Catproduct'])) {
				$this->Session->setFlash(__('Sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Sủa không thành công. Vui long thử lại', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Catproduct->read(null, $id);
			$this->parent_id = $this->Catproduct->read(null, $id);
		}
		//pr($this->data);die;
		$this->set('list_cat',$this->_find_list());
	}
	function edit2($id = null) {
		$this->account();
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if($this->data['Catproduct']['parent_id']=="")
			{
				$this->data['Catproduct']['level']=0;
			}else
			{
				$level=$this->Catproduct->read(null,$this->data['Catproduct']['parent_id']);	
				$this->data['Catproduct']['level']=$level['Catproduct']['level']+1;
			}
			if ($this->Catproduct->save($this->data)) {
				$this->Session->setFlash(__('Sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Sủa không thành công. Vui long thử lại', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Catproduct->read(null, $id);
			$this->parent_id = $this->Catproduct->read(null, $id);
		}
		//pr($this->data);die;
		$this->set('list_cat',$this->_find_list());
	}
	
	//dong danh muc
	function close($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Catproduct'] = $this->data['Catproduct'];
		$data['Catproduct']['id']=$id;
		$data['Catproduct']['status']=0;		
		if ($this->Catproduct->save($data['Catproduct'])) {
			$this->Session->setFlash(__('Danh mục không được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Danh mục không close được', true));
		$this->redirect(array('action' => 'index'));

	}
	// kich hoat
	function active($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Catproduct'] = $this->data['Catproduct'];
		$data['Catproduct']['id']=$id;
		$data['Catproduct']['status']=1;
		if ($this->Catproduct->save($data['Catproduct'])) {
			$this->Session->setFlash(__('Danh mục kích hoạt thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Danh mục không kich hoạt được', true));
		$this->redirect(array('action' => 'index'));

	}

	//Xoa danh muc
	function delete($id = null) {	
		$this->account();	
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Catproduct->delete($id)) {
			$this->Session->setFlash(__('Xóa danh mục thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Danh mục không xóa được', true));
		$this->redirect(array('action' => 'index'));
	}
	//list danh sach cac danh muc
	function _find_list() {
		return $this->Catproduct->generatetreelist(null, null, null, '--- ');
	}
	//check ton tai tai khoan
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>
