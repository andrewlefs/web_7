<?php
class CommentController extends AppController {

	var $name = 'Comment';
	var $uses=array('Category','News','Gallery','Helps','Video','Slideshow','Partner');
		var $helpers = array('Html', 'Form', 'Javascript', 'TvFck');

	//thong tin thi truong

	function menu5(){
		return $this->News->find('all',array('conditions'=>array('News.status'=>1,'News.category_id'=>array(274,290)),'order'=>'News.id DESC'));
	}

	function anhbg($id=null){
		return  $this->Album->find('all',array('conditions'=>array('Album.display2'=>1),'order'=>'Album.id DESC'));		
	}
function danhmuccha($id=null){
		return  $this->Category->find('all',array('conditions'=>array('Category.level'=>0,'Category.display not'=>array(5,6,7)),'order'=>'Category.id DESC'));		
	}
function danhmuccha2(){
		return  $this->Category->find('all',array('conditions'=>array('Category.level'=>0,'Category.display not'=>array(1,9)),'order'=>'Category.id DESC'));		
	}
	
	function menu2($id=null){
			$x=$this->Category->read(null,$id);

		
		return $this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.lft >='=>$x['Category']['lft'],'Category.rght <='=>$x['Category']['rght']),'order'=>'Category.id DESC'));
	}
	
		function menu3(){
		
		return $this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.display'=>3),'order'=>'Category.id DESC'));
	}
	function menu4(){
		
		return $this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.level'=>1,'Category.display'=>4),'order'=>'Category.id DESC'));
	}
	function farther($id=null){
		return $this->Category->read(null,$id);	

		
	}

	
}

?>
