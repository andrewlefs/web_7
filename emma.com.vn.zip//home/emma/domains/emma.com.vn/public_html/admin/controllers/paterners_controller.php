<?php
class PaternersController extends AppController {

	var $name = 'Paterners';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category'); 
	function index($id=null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$data['Overall'] = $this->data['Overall'];
			//$hinhbaner=explode('/',$_POST['wbaner']);
			//$hinh=explode('/',$_POST['wbaner'])	;
			//$type=explode('.',$hinh[3])	;
			//$hinhlogo=explode('/',$_POST['logo']);
			//$hinhgh=explode('/',$_POST['whinh']);
			
			

			$data['Overall']['ptchose']=$_POST['wlogo'].'/'.$_POST['hlogo'].'/'.$_POST['logotrai'].'/'.$_POST['logophai'].'/'.$_POST['checkgh'].'/'.$_POST['g1'].'/'.$_POST['g2'].'/'.$_POST['g3'];
			$data['Overall']['ptcss']=2;
			$data['Overall']['pthtml']=2;
//pr($data['Overall']);die;


if($_POST['checkgh']==0){
$ulslide='
	<?php if($this->params["controller"]=="home"){?>
    <div id="doitac"  style="float:left; background:#'.$_POST['g2'].'; margin-top:'.$_POST['logotrai'].'px; margin-bottom:'.$_POST['logophai'].'px; border-radius:'.$_POST['g1'].'px; overflow:hidden; height:'.($_POST['hlogo']+40).'px;">
        <script language="javascript" type="text/javascript">

            $(function() {
           
				$("#amazon_scroller2").amazon_scroller({
                    scroller_title_show: "disable",
                    scroller_time_interval: "3000",
                    scroller_window_background_color: "none",
                    scroller_window_padding: "10",
                    scroller_border_size: "0",
                    scroller_border_color: "#CCC",
                    scroller_images_width: "'.$_POST['wlogo'].'",
                    scroller_images_height: "'.$_POST['hlogo'].'",
                    scroller_title_size: "12",
                    scroller_title_color: "black",
                    scroller_show_count: "'.$_POST['g3'].'",
                    directory: "images"
                });
				
            });
        </script>
  <div id="amazon_scroller2" class="amazon_scroller">
                   <div class="amazon_scroller_mask" style="margin-top:10px; margin-bottom:10px;x`" >
                       <ul>
                       <?php $patner = $this->requestAction("/comment/patner");?>   
                     <?php foreach($patner as $patner) {?> 
                           <li><a href="<?php echo $patner["Gallery"]["name"]?>" title="title1" target="_blank"><img src="<?php echo $patner["Gallery"]["images"];?>" /></a></li>
                          <?php }?> 
                          </ul>
                   </div>
                   <ul class="amazon_scroller_nav">
                       <li></li>
                       <li></li>
                   </ul>
                   <div style="clear: both"></div>
                                   </div>

                	
                    
                    
                    
                </div>
					<?php }?>
';}
if($_POST['checkgh']==1){
$ulslide='
   <div id="doitac"  style="float:left; background:#'.$_POST['g2'].'; margin-top:'.$_POST['logotrai'].'px; margin-bottom:'.$_POST['logophai'].'px; border-radius:'.$_POST['g1'].'px; overflow:hidden; height:'.($_POST['hlogo']+20).'px;">
        <script language="javascript" type="text/javascript">

            $(function() {
           
				$("#amazon_scroller2").amazon_scroller({
                    scroller_title_show: "disable",
                    scroller_time_interval: "3000",
                    scroller_window_background_color: "none",
                    scroller_window_padding: "10",
                    scroller_border_size: "0",
                    scroller_border_color: "#CCC",
                    scroller_images_width: "'.$_POST['wlogo'].'",
                    scroller_images_height: "'.$_POST['hlogo'].'",
                    scroller_title_size: "12",
                    scroller_title_color: "black",
                    scroller_show_count: "'.$_POST['g3'].'",
                    directory: "images"
                });
				
            });
        </script>
  <div id="amazon_scroller2" class="amazon_scroller">
                   <div class="amazon_scroller_mask" style="margin-top:10px;margin-bottom:10px; " >
                       <ul>
                       <?php $patner = $this->requestAction("/comment/patner");?>   
                     <?php foreach($patner as $patner) {?> 
                           <li><a href="<?php echo $patner["Gallery"]["name"]?>" title="title1" target="_blank"><img src="<?php echo $patner["Gallery"]["images"];?>" /></a></li>
                          <?php }?> 
                          </ul>
                   </div>
                   <ul class="amazon_scroller_nav">
                       <li></li>
                       <li></li>
                   </ul>
                   <div style="clear: both"></div>
                                   </div>

                	
                    
                    
                    
                </div>
';}





$ftong1="../../app/views/elements/paterner.ctp"; //Khai báo đường dẫn của file cần ghi dữ liệu
			// Khởi tạo css cho toàn bộn trang------------------------------------------------------------------------>
  @$fttong1=fopen($ftong1,"w"); 
$ftong1=$ulslide; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong1,$ftong1); 
	 	$data['Overall']['codepatnerhtml']=$ulslide;
	
	if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."paterners'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chosetypebaner',explode('/',$catmain['Overall']['banerchose']));
		$this->set('chosebaner',explode('/',$catmain['Overall']['ptchose']));
		//pr(explode('/a/',$catmain['Overall']['mainsize']));die;
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
	}
	//Them bai viet
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
