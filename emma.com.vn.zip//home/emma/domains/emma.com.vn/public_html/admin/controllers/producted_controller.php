<?php
class ProductedController extends AppController {

	var $name = 'Producted';
	var $helpers = array('Html', 'Form', 'Javascript', 'TvFck','xls');
	var $components = array('function');
		var $uses=array('Product','Category');

	function index($id=null) {
		$_SESSION['menu1']=50;
		  $this->account();
		$a=$this->Category->find('all',array('conditions'=>array('Category.display'=>3)));
		$this->set('cat',$a);
		//pr($a);die;

	}
	
	function listcat() {
		$id=$_GET['id'];
		$this->layout='ajax';
		if($id!=0){
			//pr($id);die;
		$x=$this->Category->read(null,$id);
		
		//pr( $x['Category']['id']);die;
		
		$this->set('cat','<a href="'.DOMAINAD.'producted/xml/'. $x['Category']['id'].'" target="_blank">Tải phần cập nhật cho danh mục '.$x['Category']['name'].'</a>');
		}
		if($id==0){
		$this->set('cat','Chọn danh mục cần cập nhật ');
		}
		//$x=$this->Product->find('all',array('conditions'=>array('Product.status'=>1,'Product.category_id'=>$id)));
		
		
		
		//pr($x);die;
	}
	function xml($id=null) {
		
				$listproduct=$this->Product->find('all',array('conditions'=>array('Product.status'=>1,'Product.category_id'=>$id)));

		//pr($listproduct);die;
			$rows = "\r\n";
	$num_rows = 1;
	foreach($listproduct as $listproduct){
		$rows=$rows.'<Row>
			<Cell><Data ss:Type="Number">'.$listproduct['Product']['id'].'</Data></Cell>
			<Cell><Data ss:Type="String">'.strip_tags(str_replace(array("<br>", "<br />"), array("\n", "\n"), $listproduct['Product']['title'])).'</Data></Cell>
			<Cell><Data ss:Type="Number">'.$listproduct['Product']['price'].'</Data></Cell>
			<Cell><Data ss:Type="Number">'.$listproduct['Product']['seller'].'</Data></Cell>
			<Cell><Data ss:Type="Number">'.$listproduct['Product']['category_id'].'</Data></Cell>
			<Cell><Data ss:Type="String">'.strip_tags(str_replace(array("<br>", "<br />"), array("\n", "\n"), $listproduct['Product']['introduction'])).'</Data></Cell>
			
			<Cell><Data ss:Type="String">'.strip_tags(str_replace(array("<br>", "<br />"), array("\n", "\n"), $listproduct['Product']['content'])).'</Data></Cell>
		   </Row>'."\r\n";
		   $num_rows ++;
	}
	
	//}
	//ob_end_clean();
	header('Content-type: text/xml');
	header('Content-Disposition: attachment; filename="San-pham-'.date("d-m-Y", time()).'.xml"');
	echo '<?xml version="1.0"?>
		<?mso-application progid="Excel.Sheet"?>
		<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
		 xmlns:o="urn:schemas-microsoft-com:office:office"
		 xmlns:x="urn:schemas-microsoft-com:office:excel"
		 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
		 xmlns:html="http://www.w3.org/TR/REC-html40">
		 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
		  <LastAuthor>www</LastAuthor>
		  <Created>'.date("Y-m-d H:m:i").'</Created>
		  <LastSaved>'.date("Y-m-d H:m:i").'</LastSaved>
		  <Version>11.5606</Version>
		 </DocumentProperties>
		 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
		  <WindowHeight>5895</WindowHeight>
		  <WindowWidth>10395</WindowWidth>
		  <WindowTopX>480</WindowTopX>
		  <WindowTopY>75</WindowTopY>
		  <ProtectStructure>False</ProtectStructure>
		  <ProtectWindows>False</ProtectWindows>
		 </ExcelWorkbook>
		 <Styles>
		  <Style ss:ID="Default" ss:Name="Normal">
		   <Alignment ss:Vertical="Bottom"/>
		   <Borders/>
		   <Font/>
		   <Interior/>
		   <NumberFormat/>
		   <Protection/>
		  </Style>
		 </Styles>
		 <Worksheet ss:Name="San-pham-'.date("Y-m-d").'">
		  <Table ss:ExpandedColumnCount="10" ss:ExpandedRowCount="'.($num_rows+1).'" x:FullColumns="1"
		   x:FullRows="1">
		   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="153"/>
		   <Column ss:AutoFitWidth="0" ss:Width="111"/>
		   <Column ss:AutoFitWidth="0" ss:Width="48.75"/>
		   <Row>
			<Cell><Data ss:Type="String">Mã hệ thống</Data></Cell>
			<Cell><Data ss:Type="String">Tên sản phẩm</Data></Cell>
			<Cell><Data ss:Type="String">Giá</Data></Cell>
			<Cell><Data ss:Type="String">Số lượng</Data></Cell>
			<Cell><Data ss:Type="String">Mã chuyên mục</Data></Cell>
			<Cell><Data ss:Type="String">Mô tả tóm tắt</Data></Cell>
			<Cell><Data ss:Type="String">Mô tả chi tiết</Data></Cell>		
		   </Row>'.$rows.'
		   </Table>
		  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
		   <Selected/>
		   <Panes>
			<Pane>
			 <Number>3</Number>
			 <ActiveRow>200</ActiveRow>
			 <ActiveCol>1</ActiveCol>
			</Pane>
		   </Panes>
		   <ProtectObjects>False</ProtectObjects>
		   <ProtectScenarios>False</ProtectScenarios>
		  </WorksheetOptions>
		 </Worksheet>
		</Workbook>';
	exit;

	}
	function add() {
		
$file_name = $_FILES['file']['name'];
	$ext = explode('.', $file_name);
	$ext = $ext[count($ext)-1];
	if($file_name !='' && strtolower($ext)=='xml'){
		
				
if( $_FILES['file']['tmp_name']) 
{ 
 $dom = DOMDocument::load( $_FILES['file']['tmp_name'] ); 
 $rows = $dom->getElementsByTagName('Row'); 
 $first_row = true; 
 foreach ($rows as $row) 
 { 
   if( !$first_row) 
   { 
     $id = ""; 
     $title = ""; 
     $price = ""; 
	 $saller = "";
	 $ctegory_id = "";
	 $introduct = "";
	 $content = "";  
     $index = 1; 
     $cells = $row->getElementsByTagName( 'Cell' ); 
     foreach( $cells as $cell ) 
     { 
       $ind = $cell->getAttribute( 'Index' ); 
       if ( $ind != null ) $index = $ind; 

       if ( $index == 1 ) $id = $cell->nodeValue; 
       if ( $index == 2 ) $title = $cell->nodeValue; 
       if ( $index == 3 ) $price = $cell->nodeValue; 
	   if ( $index == 4 ) $saller = $cell->nodeValue; 
	   if ( $index == 5 ) $ctegory_id = $cell->nodeValue; 
	   if ( $index == 6 ) $introduct = $cell->nodeValue; 
	   if ( $index == 7 ) $content = $cell->nodeValue; 
       
       $index += 1; 
     } 
      
     global $data; 
    $ax[]=array('id'=>$id,'title'=>$title,'price'=>$price,'saller'=>$saller,'ctegory_id'=>$ctegory_id,'introduct'=>$introduct,'content'=>$content);  
    
   } 

   $first_row = false; 
 } //pr($ax);die;
 $countx=count($ax);
 if($countx>0){
 for($i=0 ; $i<$countx ; $i++)
			{
				
			$data['Product'] = $this->data['Product'];
			$data['Product']['id']=$ax[$i]['id'];
			$data['Product']['title']=$ax[$i]['title'];
			$data['Product']['seller']=$ax[$i]['saller'];
			$data['Product']['price']=$ax[$i]['price'];
			$data['Product']['category_id']=$ax[$i]['ctegory_id'];
			$data['Product']['introduction']=$ax[$i]['introduct'];
			$data['Product']['content']=$ax[$i]['content'];
			$data['Product']['alias'] = $this->function->khongdau($ax[$i]['title']);
			$data['Product']['meta_key']=$ax[$i]['title'];
			$data['Product']['status']=1;
			//pr($data['Product']);die;
			$this->Product->save($data['Product']);
			
				
			
		
 
 
 }
}}
	  echo '<script language="javascript"> alert("Cập nhật tin thành công"); location.href="'.DOMAINAD.'producted";</script>';
	
	}
	else{
		  echo '<script language="javascript"> alert("Xin tải file mẫu về để cập nhật"); location.href="'.DOMAINAD.'producted";</script>';
		}
	
}
	
	function _find_list() {
		return $this->Category->generatetreelist(null, null, null, '__');
	}
	//check ton tai tai khoan
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	// chon layout
	function beforeFilter(){
		$this->layout='admin';
	}

}