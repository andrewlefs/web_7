<?php
class WeblinksController extends AppController {

	var $name = 'Weblinks';
	var $uses=array('Weblink');
	var $helpers=array('Html','Javascript');
	function index(){
		$this->account();
		$this->paginate=array('limit'=>'15','order'=>'Weblink.id DESC');
		$this->set('weblinks',$this->paginate('Weblink',array()));
		$_SESSION['menu1']=9;
	}
	function add(){
		$this->account();
		if(!empty($this->data)){
			$this->Weblink->create();
			$data['Weblink']=$this->data['Weblink'];
			
			if($this->Weblink->save($data['Weblink'])){
				$this->Session->setFlash(__('Thêm mới thành công',true));
				$this->redirect(array('action'=>'index'));
			}
			else{
				$this->Session->setFlash(__('Thêm mới thất bại'));
			}
		}
				$this->set('count', count($this->Weblink->find('all')));

	}
	
	function close($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại ', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Weblink'] = $this->data['Weblink'];
		$data['Weblink']['status']=0;
			$data['Slideshow']['id']=$id;
		if ($this->Weblink->save($data['Weblink'])) {
			$this->Session->setFlash(__('Hình ảnh không được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Hình ảnh không close được', true));
		$this->redirect(array('action' => 'index'));

	}
	
	function active($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại ', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Slideshow'] = $this->data['Slideshow'];
		$data['Slideshow']['status']=1;
		$data['Slideshow']['id']=$id;
		if ($this->Weblink->save($data['Slideshow'])) {
			$this->Session->setFlash(__('Hình ảnh được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Hình ảnh không active được', true));
		$this->redirect(array('action' => 'index'));

	}

	function delete($id = null) {
		$this->account();		
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại hình ảnh này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Weblink->delete($id)) {
			$this->Session->setFlash(__('Xóa  thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Không xóa được', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function edit($id = null) {
		$this->account();
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Weblink->save($this->data)) {
				$this->Session->setFlash(__('Sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Sủa không thành công. Vui long thử lại', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Weblink->read(null, $id);
		}
		
	}
	
	
		function _find_list() {
		return $this->Weblink->generatetreelist(null, null, null, '__');
	}
	//check ton tai tai khoan
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>