<?php  

// Import the app/vendor/xmlrpc.php library 

class XmlRpcController extends AppController { 

    // This demo doesn't need models 
    var $uses = array('User'); 
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck','xls');
    // The XML-RPC server object 
    var $server = null; 

    function index() { 
	
			$rows = "\r\n";
	$num_rows = 1;
		$rows .= '<Row>
			<Cell><Data ss:Type="Number">1</Data></Cell>
			<Cell><Data ss:Type="String">'.strip_tags(str_replace(array("<br>", "<br />"), array("\n", "\n"), 'dfhdsfjds')).'</Data></Cell>
			<Cell><Data ss:Type="String">'.strip_tags(str_replace(array("<br>", "<br />"), array("\n", "\n"),'dfdsfdsfdsf')).'</Data></Cell>
			<Cell><Data ss:Type="Number">2</Data></Cell>
			<Cell><Data ss:Type="String">'.strip_tags(str_replace(array("<br>", "<br />"), array("\n", "\n"), 'dsadsadsa')).'</Data></Cell>
			<Cell><Data ss:Type="Number">3</Data></Cell>
			<Cell><Data ss:Type="Number">4</Data></Cell>
			<Cell><Data ss:Type="Number">5</Data></Cell>
			<Cell><Data ss:Type="Number">6</Data></Cell>
			<Cell><Data ss:Type="String">'.strip_tags(str_replace(array("<br>", "<br />"), array("\n", "\n"), 'dasdsadas')).'</Data></Cell>
		   </Row>'."\r\n";
	
	//
	//ob_end_clean();
	header('Content-type: text/xml');
	header('Content-Disposition: attachment; filename="San-pham-'.date("d-m-Y", time()).'.xml"');
	echo '<?xml version="1.0"?>
		<?mso-application progid="Excel.Sheet"?>
		<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
		 xmlns:o="urn:schemas-microsoft-com:office:office"
		 xmlns:x="urn:schemas-microsoft-com:office:excel"
		 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
		 xmlns:html="http://www.w3.org/TR/REC-html40">
		 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
		  <LastAuthor>www</LastAuthor>
		  <Created>'.date("Y-m-d H:m:i").'</Created>
		  <LastSaved>'.date("Y-m-d H:m:i").'</LastSaved>
		  <Version>11.5606</Version>
		 </DocumentProperties>
		 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
		  <WindowHeight>5895</WindowHeight>
		  <WindowWidth>10395</WindowWidth>
		  <WindowTopX>480</WindowTopX>
		  <WindowTopY>75</WindowTopY>
		  <ProtectStructure>False</ProtectStructure>
		  <ProtectWindows>False</ProtectWindows>
		 </ExcelWorkbook>
		 <Styles>
		  <Style ss:ID="Default" ss:Name="Normal">
		   <Alignment ss:Vertical="Bottom"/>
		   <Borders/>
		   <Font/>
		   <Interior/>
		   <NumberFormat/>
		   <Protection/>
		  </Style>
		 </Styles>
		 <Worksheet ss:Name="San-pham-'.date("Y-m-d").'">
		  <Table ss:ExpandedColumnCount="10" ss:ExpandedRowCount="'.($num_rows+1).'" x:FullColumns="1"
		   x:FullRows="1">
		   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="153"/>
		   <Column ss:AutoFitWidth="0" ss:Width="111"/>
		   <Column ss:AutoFitWidth="0" ss:Width="48.75"/>
		   <Row>
			<Cell><Data ss:Type="String">Mã hệ thống</Data></Cell>
			<Cell><Data ss:Type="String">Tên sản phẩm</Data></Cell>
			<Cell><Data ss:Type="String">Mã sản phẩm</Data></Cell>
			<Cell><Data ss:Type="String">Giá</Data></Cell>
			<Cell><Data ss:Type="String">Mô tả</Data></Cell>			
			<Cell><Data ss:Type="String">Số lần xem</Data></Cell>
			<Cell><Data ss:Type="String">SP đặc biệt</Data></Cell>
			<Cell><Data ss:Type="String">SP mới</Data></Cell>
			<Cell><Data ss:Type="String">SP bán chạy</Data></Cell>
			<Cell><Data ss:Type="String">Số lượng tồn</Data></Cell>
		   </Row>'.$rows.'
		   </Table>
		  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
		   <Selected/>
		   <Panes>
			<Pane>
			 <Number>3</Number>
			 <ActiveRow>200</ActiveRow>
			 <ActiveCol>1</ActiveCol>
			</Pane>
		   </Panes>
		   <ProtectObjects>False</ProtectObjects>
		   <ProtectScenarios>False</ProtectScenarios>
		  </WorksheetOptions>
		 </Worksheet>
		</Workbook>';
	exit;

			
		
	}
  
     
 
     
} 

?>
